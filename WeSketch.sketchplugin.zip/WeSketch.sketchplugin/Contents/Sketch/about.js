@import "common.js"

var onRun = function(context) {
    openUrlInBrowser("https://weixin.github.io/WeSketch");
};

