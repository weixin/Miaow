@import "common.js"

var onRun = function(context) {
    openUrlInBrowser("https://github.com/weixin/wesketch/issues");
};